## D&D 2024 — Classes Optimizer (On going)

Features:

- Background-based ability boosts (+2/+1 or +1/+1/+1)
- Auto Rolls or Manual Input
- All classes shown alphabetically
- Select a class to view optimized assignment
- Clear Background button located below the Background dropdown

To run:

1. npm install
2. npm run dev
   Open the URL provided by Vite (usually http://localhost:5173)

This is a React + Vite + Tailwind Project
